import rlcompleter
import readline
readline.parse_and_bind("tab: complete")


# coding: utf-8

# # Welcome to Python!

# ## Numerics  
# Types are inferred in python.  Variables can be overwritten, and types can be reassigned.

# In[1]:

x = 3
print type(x)


# In[1]:

x = 3.0 # re-assign to a different type
print str(type(x))
print type(int(x))


# Floats and ints are immutable (Seth...let's reword this)

# In[4]:

x = 4.0
y = x
print x
y += 2
print x
print y


# ## Lists

# In[5]:

some_list = [1,2,3] # a list of ints
print "The list is %s" % some_list
print "The length of the list is %s" % len(some_list)
print "The type of some_list is %s" % type(some_list)


# Lists are mutable (this is actually an example of copying by reference...we'll talk about this tomorrow)

# In[6]:

x = [1, 2]
y = x
y.append(3)
print x


# Lists can be composed of whatever you want!

# In[7]:

some_list.append("a string")
print some_list
some_list.append(['a', 'b', 'c'])
print some_list


# In[8]:

another_list = range(10)
print another_list


# In[10]:

# indexing lists
print another_list[0]
print another_list[-1]
print another_list[2:5]


# Check for a value in a list using the "in" keyword

# In[15]:

print 1 in another_list
print -10 in another_list


# In[43]:

# remove an element
another_list.pop()
print another_list


# In[44]:

# concatenate lists
print [1, 2] + [3, 4]


# List comprehensions make code more concise

# In[18]:

print [x*2 for x in another_list]
print [x for x in another_list if x % 2 == 0]


# Map, filter, and reduce can use lambda functions

# In[20]:

print another_list
print map(lambda x: x*2, another_list)
print filter(lambda x: x % 2 == 0, another_list)
print reduce(lambda x, y: x+y, another_list)


# In[11]:

from itertools import chain, imap
def flatmap(f, items):
    return chain.from_iterable(imap(f, items))
list_of_lists = [range(3) for x in xrange(3)]
print list_of_lists
print list(flatmap(lambda x: x, list_of_lists))


# Range creates a list while xrange is an iterator

# In[47]:

print range(5)
print xrange(5)
print list(xrange(5))
for i in xrange(5):
    print i


# ## Sets

# In[13]:

some_set = {1, 2, 3}
print some_set

print dir(some_set)


# In[14]:

print 1 in some_set
print -10 in some_set


# In[15]:

some_set.add(1)
print some_set
some_set.add(4)
print some_set


# **Sets are mutable**

# In[34]:

x = {1,2}
y = x
y.add(3)
print x


# In[17]:

# cannot index a set because it has no order
some_set[1]


# ## Dictionaries

# In[21]:

some_dict = {'a': 0, 'b': 1, 'c': 2}
print some_dict['a']
print some_dict.get('a')
print some_dict.get('d')
# compare to error in key lookup
print some_dict['d']


# In[45]:

some_dict['list'] = ['a', 1, 2.0]
print some_dict


# **Dictionaries are mutable**

# In[36]:

x = {'a': 0}
y = x
y['b'] = 1
print x


# In[37]:

# loop over the keys in a dict
for key in some_dict:
    print key, some_dict[key]


# In[39]:

for key, val in some_dict.iteritems():
    print key, val


# ## Strings

# In[7]:

a = "hello"
b = "world"
print a + " " + b


# **You can index strings like lists**

# In[8]:

print a[0]
print a[1:]


# In[9]:

# split and join strings
fruits = "apple, orange, banana, mango"
list_of_fruits = fruits.split(',')
print list_of_fruits
print ", ".join(list_of_fruits)


# In[10]:

# string formatting
x = 4
pi = 3.14
print "x = %d and pi = %1.2f" % (x, pi)


# In[11]:

# strings can be looped over like lists
for char in a:
    print char,


# In[12]:

list(a)


# In[13]:

set(a)


# ## Tuples

# In[36]:

some_tuple = (1, 2)
print some_tuple[0]


# **Tuples are immutable**

# In[22]:

a=[1,2,3,4]
a_tup=tuple(a)
print 'array operations: \n' + dir(a).__str__()
print 
print 'tuple operations: \n' + dir(a_tup).__str__()


# ## Numpy

# In[14]:

import numpy as np


# In[16]:

python_list = range(100000)
numpy_array = np.arange(100000)
print type(numpy_array), type(python_list)


# In[23]:

get_ipython().magic(u'timeit square = map(lambda x: x*x, python_list)')


# In[24]:

get_ipython().magic(u'timeit square = numpy_array*numpy_array')


# In[32]:

A = np.random.randint(0, 9, size=(3,3))
print "Matrix\n", A
print "Transpose\n", A.T


# #### Matrix Multiplication

# The product C of two matrices A and B is defined as:
# 
# $$C_{i,k}=\sum_{j=1}^{N} A_{i,j}B_{j,k}$$
# 
# <img src="MatrixMult.png">

# In[82]:

def multiply(A, B):
    rows = len(A[0])
    cols = len(B)
    C = [[0]*cols for i in xrange(rows)]
    # iterate through rows of X
    for i in range(len(A)):
       # iterate through columns of Y
       for j in range(len(B[0])):
           # iterate through rows of Y
           for k in range(len(B)):
               C[i][j] += A[i][k] * B[k][j]
    return C


# In[74]:

A = np.random.randint(0, 100*100, (100, 100))
A_list = A.tolist()


# **Timing for different ways to multiply matrices**

# In[75]:

# pure Python
get_ipython().magic(u'timeit multiply(A_list, A_list)')


# In[76]:

# Numpy array
get_ipython().magic(u'timeit np.dot(A, A)')


# In[77]:

# Numpy matrix
A_mat = np.mat(A)
get_ipython().magic(u'timeit A_mat*A_mat')


# ## Looping

# In[42]:

fruits = ['apple', 'orange', 'banana']
for idx, fruit in enumerate(fruits):
    print "fruits[%d] = %s" % (idx, fruit)


# In[43]:

colors = ['red', 'orange', 'yellow']
fruits_and_colors = zip(fruits, colors)
for fruit, color in fruits_and_colors:
    print "%s is %s" % (fruit, color)


# In[51]:

get_ipython().magic(u'timeit [num for num in range(0, 100000000, 50)]')


# In[52]:

get_ipython().magic(u'timeit [num for num in xrange(0, 100000000, 50)]')


# ## Functions

# In[53]:

def myfunc(x):
    return x*x
def mymap(f, items):
    return [f(x) for x in items]


# In[54]:

print mymap(myfunc, range(5))

