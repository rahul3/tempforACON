
# coding: utf-8

# In[2]:

import numpy as np
import matplotlib.pyplot as plt


# # Plotting A Line

# In[20]:

# define a domain to plot
x = np.array(xrange(-5,6))
print(x)

# Define slope and intercept
m = 5
b = 3
y = m * x + b

#printing x and y
print("Domain (x):")
print (x)
print("Range (y): for y = "+ str(m)+"*x + "+str(b))
print(y)

# setting figure numbers

# In[29]:
plt.figure(1)
plt.ion()
plt.plot(x,y,'-o')
plt.title("my first plot!")
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.grid()
plt.show()

# # Defining a function

# In[30]:

def line(x,m,b):
    return m * x + b


# # Intersection of Two Lines  

# ## Graphical Solution

# In[62]:

# Defining first line
m1 = -5.0; b1 = 2.0
y1 = line(x, m1, b1)

#Defining second line
m2 = 3.0; b2 = 4.0
y2 = line(x, m2, b2)


# In[63]:
plt.figure(2)
plt.ion()
plt.plot(x, y1,'-o', x, y2,'-o')
plt.grid()
plt.show()

# # Solving Equation Numerically

# Solving for the value of y at intersection first: 
# 
# $$y_I = \frac{b_1 - \frac{m_1}{m_2}\cdot b_2}{1 - \frac{m_1}{m_2}}$$
# 
# Substitute the solution into first equation to get the x intersection:
# 
# $$x_I = \frac{y_I - b_1}{m_1}$$
# 

# In[71]:

def intersectionOfTwoLines(m1, b1, m2, b2):
    yI = (b1 - m1/m2*b2) / (1 - m1/m2)
    xI = (yI - b1) / m1
    return(xI, yI)


# In[58]:

(xI, yI) = intersectionOfTwoLines(m1, b1, m2, b2)


# In[68]:

plt.plot(x,y1,"-o", x, y2, "-o", xI, yI,"-ok")
plt.grid()
plt.legend(["line 1","line 2","solution"])
print("solution")
print (xI, yI)

