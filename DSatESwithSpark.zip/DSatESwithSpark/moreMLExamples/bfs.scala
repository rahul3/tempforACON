import org.graphframes._
import org.graphframes.examples._
val g: GraphFrame = examples.Graphs.friends  // get example graph

// Search from "Esther" for users of age <= 32.
val paths:  org.apache.spark.sql.DataFrame = g.bfs.fromExpr("name = 'Esther'").toExpr("age < 32").run()
paths.show()

// Specify edge filters or max path lengths.
g.bfs.fromExpr("name = 'Esther'").toExpr("age < 32").edgeFilter("relationship != 'friend'").maxPathLength(3).run()
