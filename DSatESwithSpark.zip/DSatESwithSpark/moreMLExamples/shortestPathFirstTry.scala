import org.graphframes._

val v = spark.sqlContext.createDataFrame(List(
  ("1", "Home", 5),
  ("2", "Fountain", 20),
  ("3", "Museum", 12),
  ("4", "Waterfront", 7),
  ("5", "Park", 3),
  ("6", "Work", 4)
)).toDF("id", "name", "popularity")


val e = spark.sqlContext.createDataFrame(List(
  ("1", "2", 7),
  ("1", "6", 14),
  ("1", "3", 9),
  ("2", "3", 10),
  ("2", "4", 15),
  ("3", "4", 11),
  ("3", "6", 2),
  ("4", "5", 6),
  ("5", "6", 9)
)).toDF("src", "dst", "distance")

// Create a GraphFrame
import org.graphframes.GraphFrame
val g = GraphFrame(v, e)

