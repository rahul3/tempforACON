// simple cache example

// create an RDD with many partitions
// (lots of work to gather this data)
val test = sc.parallelize(1 to 50000,50)
//cache this data
test.cache

val t1 = System.nanoTime()
// first count will trigger evaluation of count *and* cache
test.count
val dt1 = (System.nanoTime() - t1).toDouble/1.0e9

val t2 = System.nanoTime()
// second count operates on cached data only
test.count
val dt2 = (System.nanoTime() - t2).toDouble/1.0e9

