
// QUESTION:  IS BACKGROUND TOO DARK?  


//immutability e:xample
val hello = "hello"
hello += " world" //this won't work
var hello = "hello"
hello += " world" //this will work


//
//inferred type
val hello = "hello"
val hello: String = "hello"
val hello: Int = "hello" //this won't work


//expressions
if (1 == 1) "hello" else "goodbye"

// lambda expressions 
// also note the type enforcement in the definition
val comingOrGoing = (n:Int) => if (n==1) "hello" else "goodbye" 

//show multiline feature in repl also!

//code blocks as expressions with last line as result
// aka function value
val bigExpression = {
  val a = "hello" 
  val b = " world"
  a + b
}

// strong typing makes sure all cases are defined
val poorlyTypedExpression = {if (true) 1}
// poorlyTypedExpression: AnyVal = 1

val betterBranchExpression = {if (true) 1 else 0}
// betterBranchExpression: Int = 1


// also show that scope of a and b are within block


//Default Argument Example
def name(first: String = "first", last: String = "last"): String = {
    first + " " + last
}

name(first = "Martin", last = "Odersky")
name(last = "Odersky")
name("Martin")


//Singleton Objects
println("singletons")
object Hello{ def message = "HelloDefault"}
Hello.message

//Classes
println("case classes")
// not a case class, but also compact (promoting parameters to fields)
class HelloClass(val message: String)

// case class is the most compact
case class HelloCC(message: String)
// can also specify as var (case and noncase)

val test = HelloCC("hello")
println(test.message)


// companion objects (shared namespace)
object HelloCompanion{
  private val defaultMessage = "Hello!"
}

class HelloCompanion(message: String = Hello.defaultMessage) {
    println(message)
}

// go through class definitions in java vs. scala

//Tuples
val pair = (1,"a")
pair._1
pair._2
// looks like a k,v pair
val samepair = 1->"a"

//Map (this is iterable) :
val map1 = Map((1,"a"),(2,"b")) 
val map2 = Map(3 -> "c")
val map3 = map1 ++ map2

//
//map
(1 to 5).map(n =>  n + 1) 
val inMyCode = (1 to 5).map(_ + 1) 

// functions are First Class Citizens
val addOne = (n: Int) => n + 1
(1 to 5).map(n => addOne(n))
(1 to 5).map(addOne)

// other mapping operations
(1 to 5).map(n => "a" + n.toString)

// reduce as addition
(1 to 5).map(addOne).reduce((a,b)=>a+b) 
// syntactic sugar
(1 to 5).map(addOne).reduce(_+_) 

//reduce as strings
(1 to 5).map(n=>"a"+n.toString).reduce((a,b)=>a+b) 


//FlatMap example
// filter example
(1 to 5).filter(x => x > 2)

// go through some for loop examples
// pattern matching also

//example with take 
//example with foreach(println)

// a simple example of processing a collection: 
 { (1 to 5000)
 .filter(x => x > 400)
 .take(5).
 foreach(x => println("x: " + x))
}



 (1 to 5000) filter(x => x > 400) take(5) foreach(x => println("x: " + x))

