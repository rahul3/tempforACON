#pyspark does not support autocomplete natively.
# add these snippets to get autocomplete functionality!
import readline
import rlcompleter
readline.parse_and_bind("tab: complete")


data = xrange(1,30)
# print first element of iterator
print data[0]
len(data)

xrangeRDD = sc.parallelize(data, 4)
subRDD = xrangeRDD.map(lambda x: x-1)
filteredRDD = subRDD.filter(lambda x : x<10)
filteredRDD.collect()
filteredRDD.count()
