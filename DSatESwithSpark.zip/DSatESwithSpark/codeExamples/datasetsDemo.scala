case class Person(name: String, age: Long)

val caseClassDS = Seq(Person("Andy", 32)).toDS()
caseClassDS.show()

// you can access fields directly:
caseClassDS.map(x => x.age + 1).show

// creating a dataset just requires the case class

val peopleDS = spark.read.json("people.json").as[Person]
