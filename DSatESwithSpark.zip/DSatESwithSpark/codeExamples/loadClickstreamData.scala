// DEFINING ETL FUNCTIONS =================================
val maxEdgesFirstShell = 25
val maxEdgesNthShell = 20


// defining some functions to parse the incoming data

// simple mapping of 'other names to a unique index'
def getIndex(x: String): Int = x match {
    case "other-wikipedia" => 1
    case "other-empty"     => 2
    case "other-internal"  => 3    
    case "other-google"    => 4
    case "other-yahoo"     => 5
    case "other-bing"      => 6
    case "other-facebook"  => 7
    case "other-twitter"   => 8 
    case "other-other"     => 9 
    case _ => 0
}

// a function that will assign a unique index to the 'other-XX' clickFrom data
def assignOtherSourceIndex(partsLine:Array[String]): String = {
    println( "assigning other source to " + partsLine(0))
    if (partsLine(0) == "") {
//      println("empty")
      return getIndex(partsLine(3)).toString
    }
    else {
//       println("in nonblank")
       return partsLine(0)
    }
}
// filling empty number fields with a large number
def fillWithNum(element: String): String = {
    if (element == ""){ 999999999.toString }
    else {element}
}

// filling empty column fields with a filler string
def fillWithString(element: String, colNum: Int): String = {
    if (element == ""){"column"+colNum+"Fill"}
    else{element}

}


// LOADING DATA AND APPLYING ETL FUNCTIONS ================

//loading data
// full dataset is ~/1.2G and is filtered down from 2015_02_clickstream.tsv
// can be found at https://old.datahub.io/dataset/wikipedia-clickstream
// filtered so that 
val lines = sc.textFile("headPlusWatsonPlusTeslaPlusApple.tsv")
//parsing and cleaning
val parts = lines.map(l=>l.split("\t")).filter(l => !(l.contains("redlink"))). //splitting on tabs and filtering out redlinks
                                                    map(l=>Array(assignOtherSourceIndex(l), 
                                                    fillWithNum(l(1)),fillWithNum(l(2)),
                                                    fillWithString(l(3),4),fillWithString(l(4),5)))
// defining a DataFrame
case class Fields(prev_id: Int, curr_id: Int, n: Int, 
           prev_title: String, curr_title: String)

val clicksDataFrame = parts.map(
     p => Fields(p(0).toInt, p(1).toInt, p(2).toInt, p(3), p(4))).toDF

// registering dataframe
clicksDataFrame.registerTempTable("clicks")
clicksDataFrame.show(5)

// DEDUPLICATION OF DATA ==================================

//nodes should need be deduplicated
val nodes1 = (parts.map{p => Array(p(0).toString, p(3)) })
nodes1.cache()
val uniqueNodes1 = nodes1.map(x => x(0)+"-0-"+x(1)).distinct.  //trick for accessing distinct
    map(x => Array(x.split("-0-")(0), x.split("-0-")(1)))  //resplitting to original structure

val nodes2 = (parts.map{p => Array(p(1).toString, p(4)) })
nodes2.cache()             
val uniqueNodes2 = nodes2.map(x => x(0)+"-0-"+x(1)).distinct.  //trick for accessing distinct
    map(x => Array(x.split("-0-")(0), x.split("-0-")(1)))  //resplitting to original structure
                         //converting to vertex RDD


uniqueNodes1.cache
uniqueNodes2.cache
val uniqueNodesBoth = (uniqueNodes1 ++ uniqueNodes2).map(x => x(0)+"-0-"+x(1)).distinct.  //trick for accessing distinct
    map(x=>Array(x.split("-0-")(0), x.split("-0-")(1))).  //resplitting to original structure
    map{ x=> (x(0).toInt.toLong, (x(1), x(1))) }  
uniqueNodesBoth.count

//  LOADING AS GRAPHX OBJECT

// importing the graphx library
import org.apache.spark.graphx._
case class nodeFields(nodeID: Int, nodeName: String)
 
val edges = parts.map(x => Edge(x(0).toInt.toLong,x(1).toInt.toLong, x(2)) )
val defaultNode = ("default Node", "Missing")

//Graph is a wrapper to a vertex list and a edge list, with the defaultNode as well.
//It does some internal bookkeepping to maintain consistency before packaging.
val graph = Graph(uniqueNodesBoth,edges,defaultNode)
//main graph will be searched very frequently
graph.cache()
graph.vertices.take(10).foreach(println)


// DEFINING GRAPH PROCESSING FUNCTIONS ===================

def pruneGraphByMaxEdges(maxEdges: Int,  bigGraph:  Graph[(String, String),String]): 
                                                    Graph[(String, String),String] = {
    val minCount = bigGraph.triplets.sortBy(_.attr.toInt, ascending=false).
                                    map(x=>x.attr.toInt).take(maxEdges).reverse(0)

    return bigGraph.subgraph(epred = x => x.attr.toInt >= minCount)
}

def addShellToGraph(thisGraph: Graph[(String, String),String], shellNum:Int ): Graph[(String, String),String]  = {

    val searchStringList = thisGraph.triplets.map(x => x.srcAttr._1).collect
    def recursiveGraphBuild(i:Int,prevGraph: Graph[(String, String),String] ):Graph[(String, String),String] = {
        
        val currentGraph =  pruneGraphByMaxEdges(maxEdgesNthShell,
                            graph.subgraph(epred = x => x.srcAttr._1 == searchStringList(i))
                            )

        val nextGraph = Graph( graph.vertices, 
                                (prevGraph.edges++currentGraph.edges).distinct     )

        if (i == searchStringList.length - 1 ) {   
            return nextGraph
        }
        else {return recursiveGraphBuild(i+1, nextGraph)}
    }
    var i = 0
    return recursiveGraphBuild(0,thisGraph)
}




