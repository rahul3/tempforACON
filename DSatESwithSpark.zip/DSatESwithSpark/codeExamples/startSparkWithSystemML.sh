$SPARK_HOME/bin/spark-shell --executor-memory 4G --driver-memory 4G --jars $SYSTEMML_HOME/lib/systemml-1.0.0.jar 

