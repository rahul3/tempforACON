// MAIN QUERY  ============================================
//Here are a list of sites that work well for the prototype dataset

val centerVertex = "Watson_(computer)"
//val centerVertex = "Heroes"
//val centerVertex = "Tesla_Motors"
//val centerVertex = "Apple_Inc."


val smallGraph = pruneGraphByMaxEdges(maxEdgesFirstShell, 
                 graph.subgraph(epred = x => x.dstAttr._1.contains(centerVertex) && 
                               !(x.srcAttr._1.contains("other-")) && 
                               !(x.srcAttr._1 == "Main_Page"))
                )
smallGraph.cache
//smallGraph.triplets.count
val maxEdgesPerFirstShell = 50
val maxEdgesPerNthShell = 20

val t0 = System.nanoTime
// called 3 times (manually)
val graph1p1 = addShellToGraph(smallGraph,2)
val graph2p1 = addShellToGraph(graph1p1,3)
// fourth click takes longer and is not very informative (so far)
val graph3p1 = addShellToGraph(graph2p1,4)
val graph2 = graph3p1

graph2.edges.count                                                                          
val dt = ((System.nanoTime-t0)/1.0e6.round/1.0e3).toString

// WRITING FILES ========================================

val outputVertexList = (graph2.triplets.map(x=>x.srcAttr._1) ++ graph2.triplets.map(x=>x.dstAttr._1)).distinct

// getting unique indices for vertices that will be referenced in the 'links' section of the json output.
val outputVertexListZipped=outputVertexList.collect.zipWithIndex

def getLinkIndex(name: String): Int = { outputVertexListZipped.filter(x=>x._1==name)(0)._2}
centerVertex




// JSON WRITING ===========================================
import sys.process._
import java.io._

val dirname = "site"
val pw = new PrintWriter(new File(dirname+"/"+centerVertex+".json"))

// a quick way to normalize edges (not rigorous):
val maxEdgeVal = graph2.triplets.sortBy(_.attr.toInt, ascending=false).
                                        map(x=>x.attr.toInt).take(1)(0)

// recall that only *edges* are filtered, the full node list is kept at all times. 
// (it saves time when rebuilding Graphs)

// we need to extract distinct vertices from the triplets 
val outputVertexList = (graph2.triplets.map(x=>x.srcAttr._1) ++ 
                        graph2.triplets.map(x=>x.dstAttr._1)).distinct
       
//formatting vertices (lots of delimiter issues)                        
val jsonVertices = outputVertexList.map(x=>x.replace("""\""" ,"""\\""")). // backslash
                                    map(x=>x.replace("\"","\\\"")). // quote delimiters
                                    map(x=>"    {\"name\":\"" + x + "\",\"group\":1}").
                                    collect

// need to map the vertex strings to unique integers...starting from 0
val jsonEdges = graph2.triplets.map(x=> "    {\"source\":" + getLinkIndex(x.srcAttr._1).toString +
                                     ",\"target\":" + getLinkIndex(x.dstAttr._1).toString + 
                                     ",\"value\":" + (x.attr.toFloat/maxEdgeVal*100).ceil.toInt.
                                     toString  + "}"  ).collect

// writing json

pw.write("{\n")                             // main header
pw.write("  \"nodes\":[\n")                 // nodes header

for (i<-0 until jsonVertices.length){       // nodes
    if(i == jsonVertices.length-1){pw.write(jsonVertices(i))}
    else {pw.write(jsonVertices(i)+",")}
    pw.write("\n")}
pw.write("  ],\n")                          // end nodes header
pw.write("  \"links\":[\n")                 // links header

for (i<-0 until jsonEdges.length){          // links
    if(i == jsonEdges.length-1){pw.write(jsonEdges(i))}
    else {pw.write(jsonEdges(i)+",")}
    pw.write("\n")
}
pw.write("  ]\n")                           // end links header

pw.write("}")                               // main footer
pw.close


// writing new html file from template
import scala.io.Source._
val lines = fromFile(dirname +"/template.html").getLines.toArray
val pw = new java.io.PrintWriter(new File(dirname+"/"+centerVertex+".html"))

//lines.map(x=>x.replace("NAME_OF_SITE", centerVertex)).foreach(y=>pw.write(y+"\n"))
lines.map(x => x.replace("NAME_OF_SITE", centerVertex)). 
      map(x => x.replace("TIME_FOR_QUERY", " (took " + dt + "s)")).
      foreach(y=>pw.write(y+"\n"))

pw.close

