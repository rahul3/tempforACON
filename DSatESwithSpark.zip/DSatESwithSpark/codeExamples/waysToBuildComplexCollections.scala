// two ways to build up complex arrays....

def getMatrixEntry(x: Int, y: Int)= { 
    if (x > y) x + y
    if (x < y) x -y
    else 0
    }    

val test = (1 to 4).toArray.
           map(x => (1 to 4).toArray.
               map(y => (x,y, getMatrixEntry(x, y)))).flatten


// the basic idea...
for (x <- (1 to 4)) 
  for (y <- (1 to 4))
    print(x, y, getMatrixEntry(x, y) )
    print(" ")
    println()

// immutable data types require that we build recursively...pushing the "append" work
// to the stack...
def recursiveBuild(input: Array[(Int,Int,Int)], x: Int): Array[(Int,Int,Int)] = {
    if (x == 5) input 
    else 
        (1 to 4).toArray.map(y => (x,y, getMatrixEntry(x, y))) ++ 
          recursiveBuild(input, x + 1) 
   }

val builtWithComprehension = recursiveBuild(Array(), 1)

// leveraging map and lambda expressions
val builtWithMapsAndLambdas = (1 to 4).map(x => 
               (1 to 4).map(y => (x,y, getMatrixEntry(x, y)))).
               flatten.toArray


//quick printout...
builtWithComprehension zip builtWithMapsAndLambdas foreach println
